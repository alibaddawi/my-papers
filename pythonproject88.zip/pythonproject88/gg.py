import tkinter as tk
#
# Function to search for appointments by name
def search_appointments():
    search_term = search_entry.get().strip().lower()
    results.delete(1.0, tk.END)  # Clear previous results
    found = False  # Track if any results were found
    for appointment in appointment_data:
        if search_term.lower() in appointment['name'].lower():
            results.insert(tk.END,
                           f"Name: {appointment['name']}, Gender: {appointment['gender']}, Problem: {appointment['problem']}, Time: {appointment['time']}\n")
            found = True

    if not found:
        results.insert(tk.END, "No appointments found for the given name.\n")


# Function to check if the appointment time is available
def is_time_available(appointment_time):
    for appointment in appointment_data:
        if appointment['time'] == appointment_time:
            return not appointment['reserved']
    return True


# Function to create and reserve a new appointment
def create_and_reserve_appointment():
    appointment_time = time_entry.get().strip()

    if not is_time_available(appointment_time):
        result_label.config(text="Appointment time is not available.")
        return

    name = name_entry.get().strip()
    gender = gender_entry.get().strip()
    problem = problem_entry.get().strip()
    fees = fees_entry.get().strip()
    date = date_entry.get().strip()

    appointment_data.append({
        'name': name,
        'gender': gender,
        'problem': problem,
        'fees': fees,
        'date': date,
        'time': appointment_time,
        'reserved': True
    })

    write_appointments()
    result_label.config(text="New appointment reserved successfully.")

    # Clear input fields
    name_entry.delete(0, tk.END)
    gender_entry.delete(0, tk.END)
    problem_entry.delete(0, tk.END)
    fees_entry.delete(0, tk.END)
    date_entry.delete(0, tk.END)
    time_entry.delete(0, tk.END)


# Read appointment data from the file and convert it to a list of dictionaries
def read_appointments():
    appointment_data = []
    try:
        with open("appointment_Info.txt", "r") as file:
            for line in file:
                data = line.strip().split(',')
                if len(data) == 7:
                    appointment = {
                        'name': data[0],
                        'gender': data[1],
                        'problem': data[2],
                        'fees': data[3],
                        'date': data[4],
                        'time': data[5],
                        'reserved': data[6] == 'True'
                    }
                    appointment_data.append(appointment)
    except FileNotFoundError:
        pass  # Handle the case where the file doesn't exist

    return appointment_data


# Write updated appointment data back to the file
def write_appointments():
    with open("appointment_Info.txt", "w") as file:
        for appointment in appointment_data:
            reserved = 'True' if appointment['reserved'] else 'False'
            file.write(
                f"{appointment['name']},{appointment['gender']},{appointment['problem']},{appointment['fees']},{appointment['date']},{appointment['time']},{reserved}\n")


# Initialize the appointment data
appointment_data = read_appointments()

# Create the main window
root = tk.Tk()
root.title("Appointment Setter")

# Search section
search_label = tk.Label(root, text="Search by Name:")
search_label.pack()
search_entry = tk.Entry(root)
search_entry.pack()
search_button = tk.Button(root, text="Search", command=search_appointments)
search_button.pack()

# Results section
results = tk.Text(root, height=10, width=40)
results.pack()

# Reservation section
reserve_label = tk.Label(root, text="Reserve Appointment:")
reserve_label.pack()

name_label = tk.Label(root, text="Enter your name:")
name_label.pack()
name_entry = tk.Entry(root)
name_entry.pack()

gender_label = tk.Label(root, text="Enter your gender:")
gender_label.pack()
gender_entry = tk.Entry(root)
gender_entry.pack()

problem_label = tk.Label(root, text="Enter your problem:")
problem_label.pack()
problem_entry = tk.Entry(root)
problem_entry.pack()

fees_label = tk.Label(root, text="Enter fees:")
fees_label.pack()
fees_entry = tk.Entry(root)
fees_entry.pack()

date_label = tk.Label(root, text="Enter date:")
date_label.pack()
date_entry = tk.Entry(root)
date_entry.pack()

time_label = tk.Label(root, text="Enter appointment time:")
time_label.pack()
time_entry = tk.Entry(root)
time_entry.pack()

reserve_button = tk.Button(root, text="Reserve", command=create_and_reserve_appointment)
reserve_button.pack()

result_label = tk.Label(root, text="", fg="red")
result_label.pack()

root.mainloop()
